"use strict";



const calculator = {};  // implement this