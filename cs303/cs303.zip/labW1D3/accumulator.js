"use strict"

/**
 * 

 * @returns {Accumulator} constructor function
 */
function Accumulator(){
//implement this

}