"use strict"

/**
 * @returns {Calculator} this is a constructor function
 */
function Calculator() {
 //implement this
  }